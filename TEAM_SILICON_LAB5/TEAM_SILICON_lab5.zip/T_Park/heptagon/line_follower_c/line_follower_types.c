/* --- Generated the 9/4/2025 at 4:53 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. jan. 29 15:40:11 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "line_follower_types.h"

Line_follower__st_1 Line_follower__st_1_of_string(char* s) {
  if ((strcmp(s, "St_1_Right")==0)) {
    return Line_follower__St_1_Right;
  };
  if ((strcmp(s, "St_1_PIDFollower")==0)) {
    return Line_follower__St_1_PIDFollower;
  };
  if ((strcmp(s, "St_1_OASLeft")==0)) {
    return Line_follower__St_1_OASLeft;
  };
  if ((strcmp(s, "St_1_OASForward")==0)) {
    return Line_follower__St_1_OASForward;
  };
  if ((strcmp(s, "St_1_OAS")==0)) {
    return Line_follower__St_1_OAS;
  };
  if ((strcmp(s, "St_1_Left")==0)) {
    return Line_follower__St_1_Left;
  };
  if ((strcmp(s, "St_1_Intersection")==0)) {
    return Line_follower__St_1_Intersection;
  };
  if ((strcmp(s, "St_1_GoToParking")==0)) {
    return Line_follower__St_1_GoToParking;
  };
  if ((strcmp(s, "St_1_Forward")==0)) {
    return Line_follower__St_1_Forward;
  };
  if ((strcmp(s, "St_1_BlackPIDFollower")==0)) {
    return Line_follower__St_1_BlackPIDFollower;
  };
  if ((strcmp(s, "St_1_BlackForward")==0)) {
    return Line_follower__St_1_BlackForward;
  };
}

char* string_of_Line_follower__st_1(Line_follower__st_1 x, char* buf) {
  switch (x) {
    case Line_follower__St_1_Right:
      strcpy(buf, "St_1_Right");
      break;
    case Line_follower__St_1_PIDFollower:
      strcpy(buf, "St_1_PIDFollower");
      break;
    case Line_follower__St_1_OASLeft:
      strcpy(buf, "St_1_OASLeft");
      break;
    case Line_follower__St_1_OASForward:
      strcpy(buf, "St_1_OASForward");
      break;
    case Line_follower__St_1_OAS:
      strcpy(buf, "St_1_OAS");
      break;
    case Line_follower__St_1_Left:
      strcpy(buf, "St_1_Left");
      break;
    case Line_follower__St_1_Intersection:
      strcpy(buf, "St_1_Intersection");
      break;
    case Line_follower__St_1_GoToParking:
      strcpy(buf, "St_1_GoToParking");
      break;
    case Line_follower__St_1_Forward:
      strcpy(buf, "St_1_Forward");
      break;
    case Line_follower__St_1_BlackPIDFollower:
      strcpy(buf, "St_1_BlackPIDFollower");
      break;
    case Line_follower__St_1_BlackForward:
      strcpy(buf, "St_1_BlackForward");
      break;
    default:
      break;
  };
  return buf;
}

Line_follower__st Line_follower__st_of_string(char* s) {
  if ((strcmp(s, "St_Terminate")==0)) {
    return Line_follower__St_Terminate;
  };
  if ((strcmp(s, "St_Straight")==0)) {
    return Line_follower__St_Straight;
  };
  if ((strcmp(s, "St_RightStraight")==0)) {
    return Line_follower__St_RightStraight;
  };
  if ((strcmp(s, "St_ParkingRight")==0)) {
    return Line_follower__St_ParkingRight;
  };
  if ((strcmp(s, "St_ParkingLeft")==0)) {
    return Line_follower__St_ParkingLeft;
  };
  if ((strcmp(s, "St_ParkStraight")==0)) {
    return Line_follower__St_ParkStraight;
  };
  if ((strcmp(s, "St_LeftStraight")==0)) {
    return Line_follower__St_LeftStraight;
  };
  if ((strcmp(s, "St_BlackPIDFollower2")==0)) {
    return Line_follower__St_BlackPIDFollower2;
  };
  if ((strcmp(s, "St_BlackPIDFollower1")==0)) {
    return Line_follower__St_BlackPIDFollower1;
  };
  if ((strcmp(s, "St_BlackForward")==0)) {
    return Line_follower__St_BlackForward;
  };
}

char* string_of_Line_follower__st(Line_follower__st x, char* buf) {
  switch (x) {
    case Line_follower__St_Terminate:
      strcpy(buf, "St_Terminate");
      break;
    case Line_follower__St_Straight:
      strcpy(buf, "St_Straight");
      break;
    case Line_follower__St_RightStraight:
      strcpy(buf, "St_RightStraight");
      break;
    case Line_follower__St_ParkingRight:
      strcpy(buf, "St_ParkingRight");
      break;
    case Line_follower__St_ParkingLeft:
      strcpy(buf, "St_ParkingLeft");
      break;
    case Line_follower__St_ParkStraight:
      strcpy(buf, "St_ParkStraight");
      break;
    case Line_follower__St_LeftStraight:
      strcpy(buf, "St_LeftStraight");
      break;
    case Line_follower__St_BlackPIDFollower2:
      strcpy(buf, "St_BlackPIDFollower2");
      break;
    case Line_follower__St_BlackPIDFollower1:
      strcpy(buf, "St_BlackPIDFollower1");
      break;
    case Line_follower__St_BlackForward:
      strcpy(buf, "St_BlackForward");
      break;
    default:
      break;
  };
  return buf;
}

