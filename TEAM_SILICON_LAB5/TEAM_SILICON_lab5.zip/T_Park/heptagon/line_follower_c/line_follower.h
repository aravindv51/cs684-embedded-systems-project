/* --- Generated the 9/4/2025 at 4:53 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. jan. 29 15:40:11 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#ifndef LINE_FOLLOWER_H
#define LINE_FOLLOWER_H

#include "line_follower_types.h"
typedef struct Line_follower__parking_mem {
  Line_follower__st ck;
  int v_29;
  int v_27;
  int v_34;
  int v_32;
  int v_39;
  int v_37;
  int v_44;
  int v_42;
  int v_49;
  int v_47;
  int v_57;
  int v_55;
  int v_53;
  int v_51;
  int v_84;
  int v_82;
  int v_92;
  int v_90;
  int v_88;
  int v_86;
  int pnr;
  int timer_r_str_1;
  int timer_l_str_1;
  int timer_straight_1;
  int timer_left_1;
  int timer_right_1;
  int timer_str_1;
} Line_follower__parking_mem;

typedef struct Line_follower__parking_out {
  int v_l;
  int v_r;
  int dir;
} Line_follower__parking_out;

void Line_follower__parking_reset(Line_follower__parking_mem* self);

void Line_follower__parking_step(int sen1, int sen3, int ll, int lc, int cc,
                                 int rc, int rr, int ir_left, int ir_right,
                                 Line_follower__parking_out* _out,
                                 Line_follower__parking_mem* self);

typedef struct Line_follower__main_mem {
  Line_follower__st_1 ck;
  int v_291;
  int v_289;
  int v_287;
  int v_285;
  int v_345;
  int v_343;
  int v_341;
  int v_339;
  int pnr;
  int counter_1;
  Line_follower__parking_mem parking;
} Line_follower__main_mem;

typedef struct Line_follower__main_out {
  int v_l;
  int v_r;
  int dir;
} Line_follower__main_out;

void Line_follower__main_reset(Line_follower__main_mem* self);

void Line_follower__main_step(int sen0, int sen1, int sen2, int sen3,
                              int sen4, int ir_value, int ir_valueLeft,
                              int ir_valueRight,
                              Line_follower__main_out* _out,
                              Line_follower__main_mem* self);

#endif // LINE_FOLLOWER_H
