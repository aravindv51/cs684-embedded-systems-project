/* --- Generated the 9/4/2025 at 4:53 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. jan. 29 15:40:11 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#ifndef LINE_FOLLOWER_H
#define LINE_FOLLOWER_H

#include "line_follower_types.h"
typedef struct Line_follower__parking_mem {
  Line_follower__st ck;
  long v_29;
  long v_27;
  long v_34;
  long v_32;
  long v_39;
  long v_37;
  long v_44;
  long v_42;
  long v_49;
  long v_47;
  long v_57;
  long v_55;
  long v_53;
  long v_51;
  long v_84;
  long v_82;
  long v_92;
  long v_90;
  long v_88;
  long v_86;
  long pnr;
  long timer_r_str_1;
  long timer_l_str_1;
  long timer_straight_1;
  long timer_left_1;
  long timer_right_1;
  long timer_str_1;
} Line_follower__parking_mem;

typedef struct Line_follower__parking_out {
  long v_l;
  long v_r;
  long dir;
} Line_follower__parking_out;

void Line_follower__parking_reset(Line_follower__parking_mem* self);

void Line_follower__parking_step(long sen1, long sen3, long ll, long lc, long cc,
                                 long rc, long rr, long ir_left, long ir_right,
                                 Line_follower__parking_out* _out,
                                 Line_follower__parking_mem* self);

typedef struct Line_follower__main_mem {
  Line_follower__st_1 ck;
  long v_291;
  long v_289;
  long v_287;
  long v_285;
  long v_345;
  long v_343;
  long v_341;
  long v_339;
  long pnr;
  long counter_1;
  Line_follower__parking_mem parking;
} Line_follower__main_mem;

typedef struct Line_follower__main_out {
  long v_l;
  long v_r;
  long dir;
} Line_follower__main_out;

void Line_follower__main_reset(Line_follower__main_mem* self);

void Line_follower__main_step(long sen0, long sen1, long sen2, long sen3,
                              long sen4, long ir_value, long ir_valueLeft,
                              long ir_valueRight,
                              Line_follower__main_out* _out,
                              Line_follower__main_mem* self);

#endif // LINE_FOLLOWER_H
