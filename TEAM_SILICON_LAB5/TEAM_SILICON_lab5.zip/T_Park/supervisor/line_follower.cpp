/* --- Generated the 9/4/2025 at 4:53 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. jan. 29 15:40:11 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "line_follower.h"

void Line_follower__parking_reset(Line_follower__parking_mem* self) {
  self->v_90 = true;
  self->v_86 = true;
  self->v_82 = true;
  self->v_55 = true;
  self->v_51 = true;
  self->v_47 = true;
  self->v_42 = true;
  self->v_37 = true;
  self->v_32 = true;
  self->v_27 = true;
  self->pnr = false;
  self->ck = Line_follower__St_BlackForward;
}

void Line_follower__parking_step(long sen1, long sen3, long ll, long lc, long cc,
                                 long rc, long rr, long ir_left, long ir_right,
                                 Line_follower__parking_out* _out,
                                 Line_follower__parking_mem* self) {
  
  long v;
  long v_1;
  long v_25;
  Line_follower__st v_24;
  long v_23;
  Line_follower__st v_22;
  long v_21;
  Line_follower__st v_20;
  long v_19;
  Line_follower__st v_18;
  long v_17;
  Line_follower__st v_16;
  long v_15;
  long v_14;
  long v_13;
  long v_12;
  long v_11;
  long v_10;
  long v_9;
  long v_8;
  long v_7;
  long v_6;
  long v_5;
  long v_4;
  long v_3;
  long v_2;
  long r_St_Terminate;
  Line_follower__st s_St_Terminate;
  long r_St_RightStraight;
  Line_follower__st s_St_RightStraight;
  long r_St_LeftStraight;
  Line_follower__st s_St_LeftStraight;
  long r_St_Straight;
  Line_follower__st s_St_Straight;
  long r_St_ParkingLeft;
  Line_follower__st s_St_ParkingLeft;
  long r_St_ParkingRight;
  Line_follower__st s_St_ParkingRight;
  long r_St_BlackPIDFollower2;
  Line_follower__st s_St_BlackPIDFollower2;
  long r_St_ParkStraight;
  Line_follower__st s_St_ParkStraight;
  long r_St_BlackPIDFollower1;
  Line_follower__st s_St_BlackPIDFollower1;
  long r_St_BlackForward;
  Line_follower__st s_St_BlackForward;
  long v_30;
  long v_28;
  long v_26;
  long v_35;
  long v_33;
  long v_31;
  long v_40;
  long v_38;
  long v_36;
  long v_45;
  long v_43;
  long v_41;
  long v_50;
  long v_48;
  long v_46;
  long v_70;
  long v_69;
  long v_68;
  long v_67;
  long v_66;
  long v_65;
  long v_64;
  long v_63;
  long v_62;
  long v_61;
  long v_60;
  long v_59;
  long v_58;
  long v_56;
  long v_54;
  long v_52;
  long error_1;
  long error_longegral_1;
  long error_derivative_1;
  long temp_value_1;
  long pid_value_1;
  long v_85;
  long v_83;
  long v_81;
  Line_follower__st v_80;
  long v_79;
  Line_follower__st v_78;
  long v_77;
  long v_76;
  long v_75;
  long v_74;
  long v_73;
  long v_72;
  long v_71;
  long v_105;
  long v_104;
  long v_103;
  long v_102;
  long v_101;
  long v_100;
  long v_99;
  long v_98;
  long v_97;
  long v_96;
  long v_95;
  long v_94;
  long v_93;
  long v_91;
  long v_89;
  long v_87;
  long error;
  long error_longegral;
  long error_derivative;
  long temp_value;
  long pid_value;
  long nr_St_Terminate;
  Line_follower__st ns_St_Terminate;
  long timer_r_str_St_Terminate;
  long timer_l_str_St_Terminate;
  long timer_straight_St_Terminate;
  long timer_left_St_Terminate;
  long timer_right_St_Terminate;
  long timer_str_St_Terminate;
  long dir_St_Terminate;
  long v_r_St_Terminate;
  long v_l_St_Terminate;
  long nr_St_RightStraight;
  Line_follower__st ns_St_RightStraight;
  long timer_r_str_St_RightStraight;
  long timer_l_str_St_RightStraight;
  long timer_straight_St_RightStraight;
  long timer_left_St_RightStraight;
  long timer_right_St_RightStraight;
  long timer_str_St_RightStraight;
  long dir_St_RightStraight;
  long v_r_St_RightStraight;
  long v_l_St_RightStraight;
  long nr_St_LeftStraight;
  Line_follower__st ns_St_LeftStraight;
  long timer_r_str_St_LeftStraight;
  long timer_l_str_St_LeftStraight;
  long timer_straight_St_LeftStraight;
  long timer_left_St_LeftStraight;
  long timer_right_St_LeftStraight;
  long timer_str_St_LeftStraight;
  long dir_St_LeftStraight;
  long v_r_St_LeftStraight;
  long v_l_St_LeftStraight;
  long nr_St_Straight;
  Line_follower__st ns_St_Straight;
  long timer_r_str_St_Straight;
  long timer_l_str_St_Straight;
  long timer_straight_St_Straight;
  long timer_left_St_Straight;
  long timer_right_St_Straight;
  long timer_str_St_Straight;
  long dir_St_Straight;
  long v_r_St_Straight;
  long v_l_St_Straight;
  long nr_St_ParkingLeft;
  Line_follower__st ns_St_ParkingLeft;
  long timer_r_str_St_ParkingLeft;
  long timer_l_str_St_ParkingLeft;
  long timer_straight_St_ParkingLeft;
  long timer_left_St_ParkingLeft;
  long timer_right_St_ParkingLeft;
  long timer_str_St_ParkingLeft;
  long dir_St_ParkingLeft;
  long v_r_St_ParkingLeft;
  long v_l_St_ParkingLeft;
  long nr_St_ParkingRight;
  Line_follower__st ns_St_ParkingRight;
  long timer_r_str_St_ParkingRight;
  long timer_l_str_St_ParkingRight;
  long timer_straight_St_ParkingRight;
  long timer_left_St_ParkingRight;
  long timer_right_St_ParkingRight;
  long timer_str_St_ParkingRight;
  long dir_St_ParkingRight;
  long v_r_St_ParkingRight;
  long v_l_St_ParkingRight;
  long nr_St_BlackPIDFollower2;
  Line_follower__st ns_St_BlackPIDFollower2;
  long timer_r_str_St_BlackPIDFollower2;
  long timer_l_str_St_BlackPIDFollower2;
  long timer_straight_St_BlackPIDFollower2;
  long timer_left_St_BlackPIDFollower2;
  long timer_right_St_BlackPIDFollower2;
  long timer_str_St_BlackPIDFollower2;
  long dir_St_BlackPIDFollower2;
  long v_r_St_BlackPIDFollower2;
  long v_l_St_BlackPIDFollower2;
  long nr_St_ParkStraight;
  Line_follower__st ns_St_ParkStraight;
  long timer_r_str_St_ParkStraight;
  long timer_l_str_St_ParkStraight;
  long timer_straight_St_ParkStraight;
  long timer_left_St_ParkStraight;
  long timer_right_St_ParkStraight;
  long timer_str_St_ParkStraight;
  long dir_St_ParkStraight;
  long v_r_St_ParkStraight;
  long v_l_St_ParkStraight;
  long nr_St_BlackPIDFollower1;
  Line_follower__st ns_St_BlackPIDFollower1;
  long timer_r_str_St_BlackPIDFollower1;
  long timer_l_str_St_BlackPIDFollower1;
  long timer_straight_St_BlackPIDFollower1;
  long timer_left_St_BlackPIDFollower1;
  long timer_right_St_BlackPIDFollower1;
  long timer_str_St_BlackPIDFollower1;
  long dir_St_BlackPIDFollower1;
  long v_r_St_BlackPIDFollower1;
  long v_l_St_BlackPIDFollower1;
  long nr_St_BlackForward;
  Line_follower__st ns_St_BlackForward;
  long timer_r_str_St_BlackForward;
  long timer_l_str_St_BlackForward;
  long timer_straight_St_BlackForward;
  long timer_left_St_BlackForward;
  long timer_right_St_BlackForward;
  long timer_str_St_BlackForward;
  long dir_St_BlackForward;
  long v_r_St_BlackForward;
  long v_l_St_BlackForward;
  Line_follower__st ck_1;
  Line_follower__st s;
  Line_follower__st ns;
  long r;
  long nr;
  long timer_str;
  long timer_right;
  long timer_left;
  long timer_straight;
  long timer_l_str;
  long timer_r_str;
  switch (self->ck) {
    case Line_follower__St_BlackForward:
      v_14 = !(ir_right);
      v_13 = !(ir_left);
      v_15 = (v_13&&v_14);
      if (v_15) {
        v_17 = true;
        v_16 = Line_follower__St_RightStraight;
      } else {
        v_17 = self->pnr;
        v_16 = Line_follower__St_BlackForward;
      };
      v_11 = !(ir_left);
      v_12 = (ir_left&&v_11);
      if (v_12) {
        v_19 = true;
        v_18 = Line_follower__St_RightStraight;
      } else {
        v_19 = v_17;
        v_18 = v_16;
      };
      v_9 = !(ir_left);
      v_10 = (v_9&&ir_right);
      if (v_10) {
        v_21 = true;
        v_20 = Line_follower__St_LeftStraight;
      } else {
        v_21 = v_19;
        v_20 = v_18;
      };
      v_8 = (ir_left&&ir_right);
      if (v_8) {
        v_23 = true;
        v_22 = Line_follower__St_ParkStraight;
      } else {
        v_23 = v_21;
        v_22 = v_20;
      };
      v_5 = !(rc);
      v_6 = (v_5&&ll);
      v_7 = (v_6&&lc);
      if (v_7) {
        v_25 = true;
        v_24 = Line_follower__St_BlackPIDFollower1;
      } else {
        v_25 = v_23;
        v_24 = v_22;
      };
      v_2 = !(lc);
      v_3 = (v_2&&rc);
      v_4 = (v_3&&rr);
      if (v_4) {
        r_St_BlackForward = true;
        s_St_BlackForward = Line_follower__St_BlackPIDFollower1;
      } else {
        r_St_BlackForward = v_25;
        s_St_BlackForward = v_24;
      };
      s = s_St_BlackForward;
      r = r_St_BlackForward;
      break;
    case Line_follower__St_BlackPIDFollower1:
      v_1 = !(cc);
      if (v_1) {
        r_St_BlackPIDFollower1 = true;
        s_St_BlackPIDFollower1 = Line_follower__St_BlackForward;
      } else {
        r_St_BlackPIDFollower1 = self->pnr;
        s_St_BlackPIDFollower1 = Line_follower__St_BlackPIDFollower1;
      };
      s = s_St_BlackPIDFollower1;
      r = r_St_BlackPIDFollower1;
      break;
    case Line_follower__St_ParkStraight:
      r_St_ParkStraight = self->pnr;
      s_St_ParkStraight = Line_follower__St_ParkStraight;
      s = s_St_ParkStraight;
      r = r_St_ParkStraight;
      break;
    case Line_follower__St_BlackPIDFollower2:
      v = !(cc);
      if (v) {
        r_St_BlackPIDFollower2 = true;
        s_St_BlackPIDFollower2 = Line_follower__St_ParkStraight;
      } else {
        r_St_BlackPIDFollower2 = self->pnr;
        s_St_BlackPIDFollower2 = Line_follower__St_BlackPIDFollower2;
      };
      s = s_St_BlackPIDFollower2;
      r = r_St_BlackPIDFollower2;
      break;
    case Line_follower__St_ParkingRight:
      r_St_ParkingRight = self->pnr;
      s_St_ParkingRight = Line_follower__St_ParkingRight;
      s = s_St_ParkingRight;
      r = r_St_ParkingRight;
      break;
    case Line_follower__St_ParkingLeft:
      r_St_ParkingLeft = self->pnr;
      s_St_ParkingLeft = Line_follower__St_ParkingLeft;
      s = s_St_ParkingLeft;
      r = r_St_ParkingLeft;
      break;
    case Line_follower__St_Straight:
      r_St_Straight = self->pnr;
      s_St_Straight = Line_follower__St_Straight;
      s = s_St_Straight;
      r = r_St_Straight;
      break;
    case Line_follower__St_LeftStraight:
      r_St_LeftStraight = self->pnr;
      s_St_LeftStraight = Line_follower__St_LeftStraight;
      s = s_St_LeftStraight;
      r = r_St_LeftStraight;
      break;
    case Line_follower__St_RightStraight:
      r_St_RightStraight = self->pnr;
      s_St_RightStraight = Line_follower__St_RightStraight;
      s = s_St_RightStraight;
      r = r_St_RightStraight;
      break;
    case Line_follower__St_Terminate:
      r_St_Terminate = self->pnr;
      s_St_Terminate = Line_follower__St_Terminate;
      s = s_St_Terminate;
      r = r_St_Terminate;
      break;
    default:
      break;
  };
  ck_1 = s;
  switch (ck_1) {
    case Line_follower__St_BlackForward:
      timer_r_str_St_BlackForward = self->timer_r_str_1;
      timer_l_str_St_BlackForward = self->timer_l_str_1;
      timer_straight_St_BlackForward = self->timer_straight_1;
      timer_left_St_BlackForward = self->timer_left_1;
      timer_right_St_BlackForward = self->timer_right_1;
      timer_str_St_BlackForward = self->timer_str_1;
      v_r_St_BlackForward = 35;
      v_l_St_BlackForward = 35;
      dir_St_BlackForward = 1;
      nr_St_BlackForward = false;
      ns_St_BlackForward = Line_follower__St_BlackForward;
      _out->v_l = v_l_St_BlackForward;
      _out->v_r = v_r_St_BlackForward;
      _out->dir = dir_St_BlackForward;
      timer_str = timer_str_St_BlackForward;
      timer_right = timer_right_St_BlackForward;
      timer_left = timer_left_St_BlackForward;
      timer_straight = timer_straight_St_BlackForward;
      timer_l_str = timer_l_str_St_BlackForward;
      timer_r_str = timer_r_str_St_BlackForward;
      ns = ns_St_BlackForward;
      nr = nr_St_BlackForward;
      break;
    case Line_follower__St_BlackPIDFollower1:
      timer_r_str_St_BlackPIDFollower1 = self->timer_r_str_1;
      timer_l_str_St_BlackPIDFollower1 = self->timer_l_str_1;
      timer_straight_St_BlackPIDFollower1 = self->timer_straight_1;
      timer_left_St_BlackPIDFollower1 = self->timer_left_1;
      timer_right_St_BlackPIDFollower1 = self->timer_right_1;
      timer_str_St_BlackPIDFollower1 = self->timer_str_1;
      if (self->v_90) {
        v_91 = true;
      } else {
        v_91 = r;
      };
      if (v_91) {
        v_93 = 0;
      } else {
        v_93 = self->v_92;
      };
      if (self->v_86) {
        v_87 = true;
      } else {
        v_87 = r;
      };
      error = (sen3-sen1);
      v_94 = (error/Line_follower__kp);
      error_derivative = (error-v_93);
      v_97 = (error_derivative/Line_follower__kd);
      v_89 = (self->v_88+error);
      if (v_87) {
        error_longegral = 0;
      } else {
        error_longegral = v_89;
      };
      v_95 = (error_longegral/Line_follower__ki);
      v_96 = (v_94+v_95);
      temp_value = (v_96+v_97);
      v_98 = (temp_value<0);
      if (v_98) {
        pid_value = -20;
      } else {
        pid_value = 20;
      };
      v_103 = (pid_value==0);
      v_102 = (30+pid_value);
      v_101 = (pid_value==0);
      if (v_101) {
        v_r_St_BlackPIDFollower1 = 25;
      } else {
        v_r_St_BlackPIDFollower1 = v_102;
      };
      v_100 = (30-pid_value);
      v_99 = (pid_value==0);
      if (v_99) {
        v_l_St_BlackPIDFollower1 = 25;
      } else {
        v_l_St_BlackPIDFollower1 = v_100;
      };
      nr_St_BlackPIDFollower1 = false;
      ns_St_BlackPIDFollower1 = Line_follower__St_BlackPIDFollower1;
      _out->v_l = v_l_St_BlackPIDFollower1;
      _out->v_r = v_r_St_BlackPIDFollower1;
      v_104 = (_out->v_l<_out->v_r);
      if (v_104) {
        v_105 = 2;
      } else {
        v_105 = 3;
      };
      if (v_103) {
        dir_St_BlackPIDFollower1 = 1;
      } else {
        dir_St_BlackPIDFollower1 = v_105;
      };
      _out->dir = dir_St_BlackPIDFollower1;
      timer_str = timer_str_St_BlackPIDFollower1;
      timer_right = timer_right_St_BlackPIDFollower1;
      timer_left = timer_left_St_BlackPIDFollower1;
      timer_straight = timer_straight_St_BlackPIDFollower1;
      timer_l_str = timer_l_str_St_BlackPIDFollower1;
      timer_r_str = timer_r_str_St_BlackPIDFollower1;
      ns = ns_St_BlackPIDFollower1;
      nr = nr_St_BlackPIDFollower1;
      self->v_92 = error;
      self->v_90 = false;
      self->v_88 = error_longegral;
      self->v_86 = false;
      break;
    case Line_follower__St_ParkStraight:
      timer_r_str_St_ParkStraight = self->timer_r_str_1;
      timer_l_str_St_ParkStraight = self->timer_l_str_1;
      timer_straight_St_ParkStraight = self->timer_straight_1;
      timer_left_St_ParkStraight = self->timer_left_1;
      timer_right_St_ParkStraight = self->timer_right_1;
      v_85 = (self->v_84-1);
      if (self->v_82) {
        v_83 = true;
      } else {
        v_83 = r;
      };
      if (v_83) {
        timer_str_St_ParkStraight = 40;
      } else {
        timer_str_St_ParkStraight = v_85;
      };
      v_r_St_ParkStraight = 35;
      v_l_St_ParkStraight = 35;
      dir_St_ParkStraight = 1;
      v_75 = !(rc);
      v_76 = (v_75&&ll);
      v_77 = (v_76&&lc);
      if (v_77) {
        v_79 = true;
        v_78 = Line_follower__St_BlackPIDFollower2;
      } else {
        v_79 = false;
        v_78 = Line_follower__St_ParkStraight;
      };
      v_72 = !(lc);
      v_73 = (v_72&&rc);
      v_74 = (v_73&&rr);
      if (v_74) {
        v_81 = true;
        v_80 = Line_follower__St_BlackPIDFollower2;
      } else {
        v_81 = v_79;
        v_80 = v_78;
      };
      _out->v_l = v_l_St_ParkStraight;
      _out->v_r = v_r_St_ParkStraight;
      _out->dir = dir_St_ParkStraight;
      timer_str = timer_str_St_ParkStraight;
      v_71 = (timer_str==0);
      if (v_71) {
        nr_St_ParkStraight = true;
        ns_St_ParkStraight = Line_follower__St_ParkingRight;
      } else {
        nr_St_ParkStraight = v_81;
        ns_St_ParkStraight = v_80;
      };
      timer_right = timer_right_St_ParkStraight;
      timer_left = timer_left_St_ParkStraight;
      timer_straight = timer_straight_St_ParkStraight;
      timer_l_str = timer_l_str_St_ParkStraight;
      timer_r_str = timer_r_str_St_ParkStraight;
      ns = ns_St_ParkStraight;
      nr = nr_St_ParkStraight;
      self->v_84 = timer_str;
      self->v_82 = false;
      break;
    case Line_follower__St_BlackPIDFollower2:
      timer_r_str_St_BlackPIDFollower2 = self->timer_r_str_1;
      timer_l_str_St_BlackPIDFollower2 = self->timer_l_str_1;
      timer_straight_St_BlackPIDFollower2 = self->timer_straight_1;
      timer_left_St_BlackPIDFollower2 = self->timer_left_1;
      timer_right_St_BlackPIDFollower2 = self->timer_right_1;
      timer_str_St_BlackPIDFollower2 = self->timer_str_1;
      if (self->v_55) {
        v_56 = true;
      } else {
        v_56 = r;
      };
      if (v_56) {
        v_58 = 0;
      } else {
        v_58 = self->v_57;
      };
      if (self->v_51) {
        v_52 = true;
      } else {
        v_52 = r;
      };
      error_1 = (sen3-sen1);
      v_59 = (error_1/Line_follower__kp);
      error_derivative_1 = (error_1-v_58);
      v_62 = (error_derivative_1/Line_follower__kd);
      v_54 = (self->v_53+error_1);
      if (v_52) {
        error_longegral_1 = 0;
      } else {
        error_longegral_1 = v_54;
      };
      v_60 = (error_longegral_1/Line_follower__ki);
      v_61 = (v_59+v_60);
      temp_value_1 = (v_61+v_62);
      v_63 = (temp_value_1<0);
      if (v_63) {
        pid_value_1 = -20;
      } else {
        pid_value_1 = 20;
      };
      v_68 = (pid_value_1==0);
      v_67 = (30+pid_value_1);
      v_66 = (pid_value_1==0);
      if (v_66) {
        v_r_St_BlackPIDFollower2 = 25;
      } else {
        v_r_St_BlackPIDFollower2 = v_67;
      };
      v_65 = (30-pid_value_1);
      v_64 = (pid_value_1==0);
      if (v_64) {
        v_l_St_BlackPIDFollower2 = 25;
      } else {
        v_l_St_BlackPIDFollower2 = v_65;
      };
      nr_St_BlackPIDFollower2 = false;
      ns_St_BlackPIDFollower2 = Line_follower__St_BlackPIDFollower2;
      _out->v_l = v_l_St_BlackPIDFollower2;
      _out->v_r = v_r_St_BlackPIDFollower2;
      v_69 = (_out->v_l<_out->v_r);
      if (v_69) {
        v_70 = 2;
      } else {
        v_70 = 3;
      };
      if (v_68) {
        dir_St_BlackPIDFollower2 = 1;
      } else {
        dir_St_BlackPIDFollower2 = v_70;
      };
      _out->dir = dir_St_BlackPIDFollower2;
      timer_str = timer_str_St_BlackPIDFollower2;
      timer_right = timer_right_St_BlackPIDFollower2;
      timer_left = timer_left_St_BlackPIDFollower2;
      timer_straight = timer_straight_St_BlackPIDFollower2;
      timer_l_str = timer_l_str_St_BlackPIDFollower2;
      timer_r_str = timer_r_str_St_BlackPIDFollower2;
      ns = ns_St_BlackPIDFollower2;
      nr = nr_St_BlackPIDFollower2;
      self->v_57 = error_1;
      self->v_55 = false;
      self->v_53 = error_longegral_1;
      self->v_51 = false;
      break;
    case Line_follower__St_ParkingRight:
      timer_r_str_St_ParkingRight = self->timer_r_str_1;
      timer_l_str_St_ParkingRight = self->timer_l_str_1;
      timer_straight_St_ParkingRight = self->timer_straight_1;
      timer_left_St_ParkingRight = self->timer_left_1;
      timer_str_St_ParkingRight = self->timer_str_1;
      v_50 = (self->v_49-1);
      if (self->v_47) {
        v_48 = true;
      } else {
        v_48 = r;
      };
      if (v_48) {
        timer_right_St_ParkingRight = 7;
      } else {
        timer_right_St_ParkingRight = v_50;
      };
      v_r_St_ParkingRight = 90;
      v_l_St_ParkingRight = 90;
      dir_St_ParkingRight = 5;
      _out->v_l = v_l_St_ParkingRight;
      _out->v_r = v_r_St_ParkingRight;
      _out->dir = dir_St_ParkingRight;
      timer_str = timer_str_St_ParkingRight;
      timer_right = timer_right_St_ParkingRight;
      v_46 = (timer_right==0);
      if (v_46) {
        nr_St_ParkingRight = true;
        ns_St_ParkingRight = Line_follower__St_Straight;
      } else {
        nr_St_ParkingRight = false;
        ns_St_ParkingRight = Line_follower__St_ParkingRight;
      };
      timer_left = timer_left_St_ParkingRight;
      timer_straight = timer_straight_St_ParkingRight;
      timer_l_str = timer_l_str_St_ParkingRight;
      timer_r_str = timer_r_str_St_ParkingRight;
      ns = ns_St_ParkingRight;
      nr = nr_St_ParkingRight;
      self->v_49 = timer_right;
      self->v_47 = false;
      break;
    case Line_follower__St_ParkingLeft:
      timer_r_str_St_ParkingLeft = self->timer_r_str_1;
      timer_l_str_St_ParkingLeft = self->timer_l_str_1;
      timer_straight_St_ParkingLeft = self->timer_straight_1;
      timer_right_St_ParkingLeft = self->timer_right_1;
      timer_str_St_ParkingLeft = self->timer_str_1;
      v_45 = (self->v_44-1);
      if (self->v_42) {
        v_43 = true;
      } else {
        v_43 = r;
      };
      if (v_43) {
        timer_left_St_ParkingLeft = 4;
      } else {
        timer_left_St_ParkingLeft = v_45;
      };
      v_r_St_ParkingLeft = 90;
      v_l_St_ParkingLeft = 90;
      dir_St_ParkingLeft = 4;
      _out->v_l = v_l_St_ParkingLeft;
      _out->v_r = v_r_St_ParkingLeft;
      _out->dir = dir_St_ParkingLeft;
      timer_str = timer_str_St_ParkingLeft;
      timer_right = timer_right_St_ParkingLeft;
      timer_left = timer_left_St_ParkingLeft;
      v_41 = (timer_left==0);
      if (v_41) {
        nr_St_ParkingLeft = true;
        ns_St_ParkingLeft = Line_follower__St_Straight;
      } else {
        nr_St_ParkingLeft = false;
        ns_St_ParkingLeft = Line_follower__St_ParkingLeft;
      };
      timer_straight = timer_straight_St_ParkingLeft;
      timer_l_str = timer_l_str_St_ParkingLeft;
      timer_r_str = timer_r_str_St_ParkingLeft;
      ns = ns_St_ParkingLeft;
      nr = nr_St_ParkingLeft;
      self->v_44 = timer_left;
      self->v_42 = false;
      break;
    case Line_follower__St_Straight:
      timer_r_str_St_Straight = self->timer_r_str_1;
      timer_l_str_St_Straight = self->timer_l_str_1;
      timer_left_St_Straight = self->timer_left_1;
      timer_right_St_Straight = self->timer_right_1;
      timer_str_St_Straight = self->timer_str_1;
      v_40 = (self->v_39-1);
      if (self->v_37) {
        v_38 = true;
      } else {
        v_38 = r;
      };
      if (v_38) {
        timer_straight_St_Straight = 20;
      } else {
        timer_straight_St_Straight = v_40;
      };
      v_r_St_Straight = 35;
      v_l_St_Straight = 35;
      dir_St_Straight = 1;
      _out->v_l = v_l_St_Straight;
      _out->v_r = v_r_St_Straight;
      _out->dir = dir_St_Straight;
      timer_str = timer_str_St_Straight;
      timer_right = timer_right_St_Straight;
      timer_left = timer_left_St_Straight;
      timer_straight = timer_straight_St_Straight;
      v_36 = (timer_straight==0);
      if (v_36) {
        nr_St_Straight = true;
        ns_St_Straight = Line_follower__St_Terminate;
      } else {
        nr_St_Straight = false;
        ns_St_Straight = Line_follower__St_Straight;
      };
      timer_l_str = timer_l_str_St_Straight;
      timer_r_str = timer_r_str_St_Straight;
      ns = ns_St_Straight;
      nr = nr_St_Straight;
      self->v_39 = timer_straight;
      self->v_37 = false;
      break;
    case Line_follower__St_LeftStraight:
      timer_r_str_St_LeftStraight = self->timer_r_str_1;
      timer_straight_St_LeftStraight = self->timer_straight_1;
      timer_left_St_LeftStraight = self->timer_left_1;
      timer_right_St_LeftStraight = self->timer_right_1;
      timer_str_St_LeftStraight = self->timer_str_1;
      v_35 = (self->v_34-1);
      if (self->v_32) {
        v_33 = true;
      } else {
        v_33 = r;
      };
      if (v_33) {
        timer_l_str_St_LeftStraight = 20;
      } else {
        timer_l_str_St_LeftStraight = v_35;
      };
      v_r_St_LeftStraight = 35;
      v_l_St_LeftStraight = 35;
      dir_St_LeftStraight = 1;
      _out->v_l = v_l_St_LeftStraight;
      _out->v_r = v_r_St_LeftStraight;
      _out->dir = dir_St_LeftStraight;
      timer_str = timer_str_St_LeftStraight;
      timer_right = timer_right_St_LeftStraight;
      timer_left = timer_left_St_LeftStraight;
      timer_straight = timer_straight_St_LeftStraight;
      timer_l_str = timer_l_str_St_LeftStraight;
      v_31 = (timer_l_str==0);
      if (v_31) {
        nr_St_LeftStraight = true;
        ns_St_LeftStraight = Line_follower__St_ParkingLeft;
      } else {
        nr_St_LeftStraight = false;
        ns_St_LeftStraight = Line_follower__St_LeftStraight;
      };
      timer_r_str = timer_r_str_St_LeftStraight;
      ns = ns_St_LeftStraight;
      nr = nr_St_LeftStraight;
      self->v_34 = timer_l_str;
      self->v_32 = false;
      break;
    case Line_follower__St_RightStraight:
      timer_l_str_St_RightStraight = self->timer_l_str_1;
      timer_straight_St_RightStraight = self->timer_straight_1;
      timer_left_St_RightStraight = self->timer_left_1;
      timer_right_St_RightStraight = self->timer_right_1;
      timer_str_St_RightStraight = self->timer_str_1;
      v_30 = (self->v_29-1);
      if (self->v_27) {
        v_28 = true;
      } else {
        v_28 = r;
      };
      if (v_28) {
        timer_r_str_St_RightStraight = 20;
      } else {
        timer_r_str_St_RightStraight = v_30;
      };
      v_r_St_RightStraight = 35;
      v_l_St_RightStraight = 35;
      dir_St_RightStraight = 1;
      _out->v_l = v_l_St_RightStraight;
      _out->v_r = v_r_St_RightStraight;
      _out->dir = dir_St_RightStraight;
      timer_str = timer_str_St_RightStraight;
      timer_right = timer_right_St_RightStraight;
      timer_left = timer_left_St_RightStraight;
      timer_straight = timer_straight_St_RightStraight;
      timer_l_str = timer_l_str_St_RightStraight;
      timer_r_str = timer_r_str_St_RightStraight;
      v_26 = (timer_r_str==0);
      if (v_26) {
        nr_St_RightStraight = true;
        ns_St_RightStraight = Line_follower__St_ParkingRight;
      } else {
        nr_St_RightStraight = false;
        ns_St_RightStraight = Line_follower__St_RightStraight;
      };
      ns = ns_St_RightStraight;
      nr = nr_St_RightStraight;
      self->v_29 = timer_r_str;
      self->v_27 = false;
      break;
    case Line_follower__St_Terminate:
      timer_r_str_St_Terminate = self->timer_r_str_1;
      timer_l_str_St_Terminate = self->timer_l_str_1;
      timer_straight_St_Terminate = self->timer_straight_1;
      timer_left_St_Terminate = self->timer_left_1;
      timer_right_St_Terminate = self->timer_right_1;
      timer_str_St_Terminate = self->timer_str_1;
      v_r_St_Terminate = 0;
      v_l_St_Terminate = 0;
      dir_St_Terminate = 1;
      nr_St_Terminate = false;
      ns_St_Terminate = Line_follower__St_Terminate;
      _out->v_l = v_l_St_Terminate;
      _out->v_r = v_r_St_Terminate;
      _out->dir = dir_St_Terminate;
      timer_str = timer_str_St_Terminate;
      timer_right = timer_right_St_Terminate;
      timer_left = timer_left_St_Terminate;
      timer_straight = timer_straight_St_Terminate;
      timer_l_str = timer_l_str_St_Terminate;
      timer_r_str = timer_r_str_St_Terminate;
      ns = ns_St_Terminate;
      nr = nr_St_Terminate;
      break;
    default:
      break;
  };
  self->timer_r_str_1 = timer_r_str;
  self->timer_l_str_1 = timer_l_str;
  self->timer_straight_1 = timer_straight;
  self->timer_left_1 = timer_left;
  self->timer_right_1 = timer_right;
  self->timer_str_1 = timer_str;
  self->pnr = nr;
  self->ck = ns;;
}

void Line_follower__main_reset(Line_follower__main_mem* self) {
  Line_follower__parking_reset(&self->parking);
  self->counter_1 = 0;
  self->pnr = false;
  self->ck = Line_follower__St_1_Forward;
  self->v_343 = true;
  self->v_339 = true;
  self->v_289 = true;
  self->v_285 = true;
}

void Line_follower__main_step(long sen0, long sen1, long sen2, long sen3,
                              long sen4, long ir_value, long ir_valueLeft,
                              long ir_valueRight,
                              Line_follower__main_out* _out,
                              Line_follower__main_mem* self) {
  Line_follower__parking_out Line_follower__parking_out_st;
  
  long v_114;
  Line_follower__st_1 v_113;
  long v_112;
  long v_111;
  long v_110;
  long v_109;
  long v_108;
  long v_107;
  long v_115;
  long v_123;
  Line_follower__st_1 v_122;
  long v_121;
  long v_120;
  long v_119;
  long v_118;
  long v_117;
  long v_116;
  long v_140;
  Line_follower__st_1 v_139;
  long v_138;
  Line_follower__st_1 v_137;
  long v_136;
  Line_follower__st_1 v_135;
  long v_134;
  long v_133;
  long v_132;
  long v_131;
  long v_130;
  long v_129;
  long v_128;
  long v_127;
  long v_126;
  long v_125;
  long v_124;
  long v_154;
  Line_follower__st_1 v_153;
  long v_152;
  Line_follower__st_1 v_151;
  long v_150;
  Line_follower__st_1 v_149;
  long v_148;
  long v_147;
  long v_146;
  long v_145;
  long v_144;
  long v_143;
  long v_142;
  long v_141;
  long v_210;
  Line_follower__st_1 v_209;
  long v_208;
  Line_follower__st_1 v_207;
  long v_206;
  Line_follower__st_1 v_205;
  long v_204;
  Line_follower__st_1 v_203;
  long v_202;
  Line_follower__st_1 v_201;
  long v_200;
  Line_follower__st_1 v_199;
  long v_198;
  Line_follower__st_1 v_197;
  long v_196;
  Line_follower__st_1 v_195;
  long v_194;
  Line_follower__st_1 v_193;
  long v_192;
  long v_191;
  long v_190;
  long v_189;
  long v_188;
  long v_187;
  long v_186;
  long v_185;
  long v_184;
  long v_183;
  long v_182;
  long v_181;
  long v_180;
  long v_179;
  long v_178;
  long v_177;
  long v_176;
  long v_175;
  long v_174;
  long v_173;
  long v_172;
  long v_171;
  long v_170;
  long v_169;
  long v_168;
  long v_167;
  long v_166;
  long v_165;
  long v_164;
  long v_163;
  long v_162;
  long v_161;
  long v_160;
  long v_159;
  long v_158;
  long v_157;
  long v_156;
  long v_155;
  long v_283;
  Line_follower__st_1 v_282;
  long v_281;
  Line_follower__st_1 v_280;
  long v_279;
  Line_follower__st_1 v_278;
  long v_277;
  Line_follower__st_1 v_276;
  long v_275;
  Line_follower__st_1 v_274;
  long v_273;
  Line_follower__st_1 v_272;
  long v_271;
  Line_follower__st_1 v_270;
  long v_269;
  Line_follower__st_1 v_268;
  long v_267;
  Line_follower__st_1 v_266;
  long v_265;
  Line_follower__st_1 v_264;
  long v_263;
  Line_follower__st_1 v_262;
  long v_261;
  long v_260;
  long v_259;
  long v_258;
  long v_257;
  long v_256;
  long v_255;
  long v_254;
  long v_253;
  long v_252;
  long v_251;
  long v_250;
  long v_249;
  long v_248;
  long v_247;
  long v_246;
  long v_245;
  long v_244;
  long v_243;
  long v_242;
  long v_241;
  long v_240;
  long v_239;
  long v_238;
  long v_237;
  long v_236;
  long v_235;
  long v_234;
  long v_233;
  long v_232;
  long v_231;
  long v_230;
  long v_229;
  long v_228;
  long v_227;
  long v_226;
  long v_225;
  long v_224;
  long v_223;
  long v_222;
  long v_221;
  long v_220;
  long v_219;
  long v_218;
  long v_217;
  long v_216;
  long v_215;
  long v_214;
  long v_213;
  long v_212;
  long v_211;
  long r_St_1_GoToParking;
  Line_follower__st_1 s_St_1_GoToParking;
  long r_St_1_OASLeft;
  Line_follower__st_1 s_St_1_OASLeft;
  long r_St_1_OASForward;
  Line_follower__st_1 s_St_1_OASForward;
  long r_St_1_OAS;
  Line_follower__st_1 s_St_1_OAS;
  long r_St_1_BlackPIDFollower;
  Line_follower__st_1 s_St_1_BlackPIDFollower;
  long r_St_1_Intersection;
  Line_follower__st_1 s_St_1_Intersection;
  long r_St_1_BlackForward;
  Line_follower__st_1 s_St_1_BlackForward;
  long r_St_1_Right;
  Line_follower__st_1 s_St_1_Right;
  long r_St_1_Left;
  Line_follower__st_1 s_St_1_Left;
  long r_St_1_PIDFollower;
  Line_follower__st_1 s_St_1_PIDFollower;
  long r_St_1_Forward;
  Line_follower__st_1 s_St_1_Forward;
  long v_284;
  long r_1;
  long v_304;
  long v_303;
  long v_302;
  long v_301;
  long v_300;
  long v_299;
  long v_298;
  long v_297;
  long v_296;
  long v_295;
  long v_294;
  long v_293;
  long v_292;
  long v_290;
  long v_288;
  long v_286;
  long error_2;
  long error_longegral_2;
  long error_derivative_2;
  long temp_value_2;
  long pid_value_2;
  long v_324;
  long v_323;
  long v_322;
  long v_321;
  long v_320;
  long v_319;
  long v_318;
  Line_follower__st_1 v_317;
  long v_316;
  Line_follower__st_1 v_315;
  long v_314;
  Line_follower__st_1 v_313;
  long v_312;
  long v_311;
  long v_310;
  long v_309;
  long v_308;
  long v_307;
  long v_306;
  long v_305;
  long timer;
  long v_338;
  Line_follower__st_1 v_337;
  long v_336;
  Line_follower__st_1 v_335;
  long v_334;
  Line_follower__st_1 v_333;
  long v_332;
  long v_331;
  long v_330;
  long v_329;
  long v_328;
  long v_327;
  long v_326;
  long v_325;
  long v_358;
  long v_357;
  long v_356;
  long v_355;
  long v_354;
  long v_353;
  long v_352;
  long v_351;
  long v_350;
  long v_349;
  long v_348;
  long v_347;
  long v_346;
  long v_344;
  long v_342;
  long v_340;
  long error;
  long error_longegral;
  long error_derivative;
  long temp_value;
  long pid_value;
  long nr_St_1_GoToParking;
  Line_follower__st_1 ns_St_1_GoToParking;
  long counter_St_1_GoToParking;
  long dir_St_1_GoToParking;
  long v_r_St_1_GoToParking;
  long v_l_St_1_GoToParking;
  long nr_St_1_OASLeft;
  Line_follower__st_1 ns_St_1_OASLeft;
  long counter_St_1_OASLeft;
  long dir_St_1_OASLeft;
  long v_r_St_1_OASLeft;
  long v_l_St_1_OASLeft;
  long nr_St_1_OASForward;
  Line_follower__st_1 ns_St_1_OASForward;
  long counter_St_1_OASForward;
  long dir_St_1_OASForward;
  long v_r_St_1_OASForward;
  long v_l_St_1_OASForward;
  long nr_St_1_OAS;
  Line_follower__st_1 ns_St_1_OAS;
  long counter_St_1_OAS;
  long dir_St_1_OAS;
  long v_r_St_1_OAS;
  long v_l_St_1_OAS;
  long nr_St_1_BlackPIDFollower;
  Line_follower__st_1 ns_St_1_BlackPIDFollower;
  long counter_St_1_BlackPIDFollower;
  long dir_St_1_BlackPIDFollower;
  long v_r_St_1_BlackPIDFollower;
  long v_l_St_1_BlackPIDFollower;
  long nr_St_1_Intersection;
  Line_follower__st_1 ns_St_1_Intersection;
  long counter_St_1_Intersection;
  long dir_St_1_Intersection;
  long v_r_St_1_Intersection;
  long v_l_St_1_Intersection;
  long nr_St_1_BlackForward;
  Line_follower__st_1 ns_St_1_BlackForward;
  long counter_St_1_BlackForward;
  long dir_St_1_BlackForward;
  long v_r_St_1_BlackForward;
  long v_l_St_1_BlackForward;
  long nr_St_1_Right;
  Line_follower__st_1 ns_St_1_Right;
  long counter_St_1_Right;
  long dir_St_1_Right;
  long v_r_St_1_Right;
  long v_l_St_1_Right;
  long nr_St_1_Left;
  Line_follower__st_1 ns_St_1_Left;
  long counter_St_1_Left;
  long dir_St_1_Left;
  long v_r_St_1_Left;
  long v_l_St_1_Left;
  long nr_St_1_PIDFollower;
  Line_follower__st_1 ns_St_1_PIDFollower;
  long counter_St_1_PIDFollower;
  long dir_St_1_PIDFollower;
  long v_r_St_1_PIDFollower;
  long v_l_St_1_PIDFollower;
  long nr_St_1_Forward;
  Line_follower__st_1 ns_St_1_Forward;
  long counter_St_1_Forward;
  long dir_St_1_Forward;
  long v_r_St_1_Forward;
  long v_l_St_1_Forward;
  Line_follower__st_1 ck_2;
  long v_106;
  long v;
  Line_follower__st_1 s;
  Line_follower__st_1 ns;
  long r;
  long nr;
  long sen[5];
  long counter;
  long ll;
  long lc;
  long cc;
  long rc;
  long rr;
  long ir_front;
  long ir_left;
  long ir_right;
  v_106 = (ir_valueRight==0);
  if (v_106) {
    ir_right = true;
  } else {
    ir_right = false;
  };
  v = (ir_valueLeft==0);
  if (v) {
    ir_left = true;
  } else {
    ir_left = false;
  };
  ir_front = (ir_value>0);
  rr = (sen4>650);
  rc = (sen3>750);
  cc = (sen2>750);
  lc = (sen1>750);
  ll = (sen0>650);
  switch (self->ck) {
    case Line_follower__St_1_Forward:
      v_260 = !(rr);
      v_258 = !(rc);
      v_256 = !(cc);
      v_255 = (ll&&lc);
      v_257 = (v_255&&v_256);
      v_259 = (v_257&&v_258);
      v_261 = (v_259&&v_260);
      if (v_261) {
        v_263 = true;
        v_262 = Line_follower__St_1_BlackForward;
      } else {
        v_263 = self->pnr;
        v_262 = Line_follower__St_1_Forward;
      };
      v_252 = (ll||lc);
      v_253 = !(v_252);
      v_254 = (rc&&v_253);
      if (v_254) {
        v_265 = true;
        v_264 = Line_follower__St_1_PIDFollower;
      } else {
        v_265 = v_263;
        v_264 = v_262;
      };
      v_249 = (rc||rr);
      v_250 = !(v_249);
      v_251 = (lc&&v_250);
      if (v_251) {
        v_267 = true;
        v_266 = Line_follower__St_1_PIDFollower;
      } else {
        v_267 = v_265;
        v_266 = v_264;
      };
      v_246 = !(rc);
      v_244 = !(cc);
      v_242 = !(ll);
      v_243 = (v_242&&lc);
      v_245 = (v_243&&v_244);
      v_247 = (v_245&&v_246);
      v_248 = (v_247&&rr);
      if (v_248) {
        v_269 = true;
        v_268 = Line_follower__St_1_BlackForward;
      } else {
        v_269 = v_267;
        v_268 = v_266;
      };
      v_239 = !(rc);
      v_237 = !(cc);
      v_236 = (ll&&lc);
      v_238 = (v_236&&v_237);
      v_240 = (v_238&&v_239);
      v_241 = (v_240&&rr);
      if (v_241) {
        v_271 = true;
        v_270 = Line_follower__St_1_BlackForward;
      } else {
        v_271 = v_269;
        v_270 = v_268;
      };
      v_232 = !(cc);
      v_230 = !(lc);
      v_231 = (ll&&v_230);
      v_233 = (v_231&&v_232);
      v_234 = (v_233&&rc);
      v_235 = (v_234&&rr);
      if (v_235) {
        v_273 = true;
        v_272 = Line_follower__St_1_BlackForward;
      } else {
        v_273 = v_271;
        v_272 = v_270;
      };
      v_225 = !(lc);
      v_226 = (ll&&v_225);
      v_227 = (v_226&&cc);
      v_228 = (v_227&&rc);
      v_229 = (v_228&&rr);
      if (v_229) {
        v_275 = true;
        v_274 = Line_follower__St_1_BlackForward;
      } else {
        v_275 = v_273;
        v_274 = v_272;
      };
      v_222 = !(rc);
      v_220 = (ll&&lc);
      v_221 = (v_220&&cc);
      v_223 = (v_221&&v_222);
      v_224 = (v_223&&rr);
      if (v_224) {
        v_277 = true;
        v_276 = Line_follower__St_1_BlackForward;
      } else {
        v_277 = v_275;
        v_276 = v_274;
      };
      v_216 = !(cc);
      v_215 = (ll&&lc);
      v_217 = (v_215&&v_216);
      v_218 = (v_217&&rc);
      v_219 = (v_218&&rr);
      if (v_219) {
        v_279 = true;
        v_278 = Line_follower__St_1_BlackForward;
      } else {
        v_279 = v_277;
        v_278 = v_276;
      };
      v_214 = (rc&&rr);
      if (v_214) {
        v_281 = true;
        v_280 = Line_follower__St_1_Right;
      } else {
        v_281 = v_279;
        v_280 = v_278;
      };
      v_213 = (cc&&rc);
      if (v_213) {
        v_283 = true;
        v_282 = Line_follower__St_1_Right;
      } else {
        v_283 = v_281;
        v_282 = v_280;
      };
      v_211 = (ll&&lc);
      v_212 = (v_211&&cc);
      if (v_212) {
        r_St_1_Forward = true;
        s_St_1_Forward = Line_follower__St_1_Left;
      } else {
        r_St_1_Forward = v_283;
        s_St_1_Forward = v_282;
      };
      s = s_St_1_Forward;
      r = r_St_1_Forward;
      break;
    case Line_follower__St_1_PIDFollower:
      v_190 = !(rc);
      v_188 = !(cc);
      v_186 = !(ll);
      v_187 = (v_186&&lc);
      v_189 = (v_187&&v_188);
      v_191 = (v_189&&v_190);
      v_192 = (v_191&&rr);
      if (v_192) {
        v_194 = true;
        v_193 = Line_follower__St_1_BlackForward;
      } else {
        v_194 = self->pnr;
        v_193 = Line_follower__St_1_PIDFollower;
      };
      v_183 = !(rc);
      v_181 = !(cc);
      v_180 = (ll&&lc);
      v_182 = (v_180&&v_181);
      v_184 = (v_182&&v_183);
      v_185 = (v_184&&rr);
      if (v_185) {
        v_196 = true;
        v_195 = Line_follower__St_1_BlackForward;
      } else {
        v_196 = v_194;
        v_195 = v_193;
      };
      v_176 = !(cc);
      v_174 = !(lc);
      v_175 = (ll&&v_174);
      v_177 = (v_175&&v_176);
      v_178 = (v_177&&rc);
      v_179 = (v_178&&rr);
      if (v_179) {
        v_198 = true;
        v_197 = Line_follower__St_1_BlackForward;
      } else {
        v_198 = v_196;
        v_197 = v_195;
      };
      v_169 = !(lc);
      v_170 = (ll&&v_169);
      v_171 = (v_170&&cc);
      v_172 = (v_171&&rc);
      v_173 = (v_172&&rr);
      if (v_173) {
        v_200 = true;
        v_199 = Line_follower__St_1_BlackForward;
      } else {
        v_200 = v_198;
        v_199 = v_197;
      };
      v_166 = !(rc);
      v_164 = (ll&&lc);
      v_165 = (v_164&&cc);
      v_167 = (v_165&&v_166);
      v_168 = (v_167&&rr);
      if (v_168) {
        v_202 = true;
        v_201 = Line_follower__St_1_BlackForward;
      } else {
        v_202 = v_200;
        v_201 = v_199;
      };
      v_160 = !(cc);
      v_159 = (ll&&lc);
      v_161 = (v_159&&v_160);
      v_162 = (v_161&&rc);
      v_163 = (v_162&&rr);
      if (v_163) {
        v_204 = true;
      } else {
        v_204 = v_202;
      };
      if (cc) {
        v_206 = true;
      } else {
        v_206 = v_204;
      };
      if (v_163) {
        v_203 = Line_follower__St_1_BlackForward;
      } else {
        v_203 = v_201;
      };
      if (cc) {
        v_205 = Line_follower__St_1_Forward;
      } else {
        v_205 = v_203;
      };
      v_158 = (rc&&rr);
      if (v_158) {
        v_208 = true;
        v_207 = Line_follower__St_1_Right;
      } else {
        v_208 = v_206;
        v_207 = v_205;
      };
      v_157 = (cc&&rc);
      if (v_157) {
        v_210 = true;
        v_209 = Line_follower__St_1_Right;
      } else {
        v_210 = v_208;
        v_209 = v_207;
      };
      v_155 = (ll&&lc);
      v_156 = (v_155&&cc);
      if (v_156) {
        r_St_1_PIDFollower = true;
        s_St_1_PIDFollower = Line_follower__St_1_Left;
      } else {
        r_St_1_PIDFollower = v_210;
        s_St_1_PIDFollower = v_209;
      };
      s = s_St_1_PIDFollower;
      r = r_St_1_PIDFollower;
      break;
    case Line_follower__St_1_Left:
      r_St_1_Left = self->pnr;
      s_St_1_Left = Line_follower__St_1_Left;
      s = s_St_1_Left;
      r = r_St_1_Left;
      break;
    case Line_follower__St_1_Right:
      if (cc) {
        v_150 = true;
        v_149 = Line_follower__St_1_Forward;
      } else {
        v_150 = self->pnr;
        v_149 = Line_follower__St_1_Right;
      };
      v_146 = (rc||rr);
      v_147 = !(v_146);
      v_148 = (lc&&v_147);
      if (v_148) {
        v_152 = true;
        v_151 = Line_follower__St_1_PIDFollower;
      } else {
        v_152 = v_150;
        v_151 = v_149;
      };
      v_143 = (ll||lc);
      v_144 = !(v_143);
      v_145 = (rc&&v_144);
      if (v_145) {
        v_154 = true;
        v_153 = Line_follower__St_1_PIDFollower;
      } else {
        v_154 = v_152;
        v_153 = v_151;
      };
      v_141 = (ll&&lc);
      v_142 = (v_141&&cc);
      if (v_142) {
        r_St_1_Right = true;
        s_St_1_Right = Line_follower__St_1_Left;
      } else {
        r_St_1_Right = v_154;
        s_St_1_Right = v_153;
      };
      s = s_St_1_Right;
      r = r_St_1_Right;
      break;
    case Line_follower__St_1_BlackForward:
      if (ir_front) {
        v_136 = true;
        v_135 = Line_follower__St_1_OAS;
      } else {
        v_136 = self->pnr;
        v_135 = Line_follower__St_1_BlackForward;
      };
      v_132 = !(rc);
      v_133 = (v_132&&ll);
      v_134 = (v_133&&lc);
      if (v_134) {
        v_138 = true;
        v_137 = Line_follower__St_1_BlackPIDFollower;
      } else {
        v_138 = v_136;
        v_137 = v_135;
      };
      v_129 = !(lc);
      v_130 = (v_129&&rc);
      v_131 = (v_130&&rr);
      if (v_131) {
        v_140 = true;
        v_139 = Line_follower__St_1_BlackPIDFollower;
      } else {
        v_140 = v_138;
        v_139 = v_137;
      };
      v_127 = !(rc);
      v_125 = !(cc);
      v_124 = !(lc);
      v_126 = (v_124&&v_125);
      v_128 = (v_126&&v_127);
      if (v_128) {
        r_St_1_BlackForward = true;
        s_St_1_BlackForward = Line_follower__St_1_Intersection;
      } else {
        r_St_1_BlackForward = v_140;
        s_St_1_BlackForward = v_139;
      };
      s = s_St_1_BlackForward;
      r = r_St_1_BlackForward;
      break;
    case Line_follower__St_1_Intersection:
      r_St_1_Intersection = self->pnr;
      s_St_1_Intersection = Line_follower__St_1_Intersection;
      s = s_St_1_Intersection;
      r = r_St_1_Intersection;
      break;
    case Line_follower__St_1_BlackPIDFollower:
      v_121 = !(cc);
      if (v_121) {
        v_123 = true;
        v_122 = Line_follower__St_1_BlackForward;
      } else {
        v_123 = self->pnr;
        v_122 = Line_follower__St_1_BlackPIDFollower;
      };
      v_119 = !(rc);
      v_117 = !(cc);
      v_116 = !(lc);
      v_118 = (v_116&&v_117);
      v_120 = (v_118&&v_119);
      if (v_120) {
        r_St_1_BlackPIDFollower = true;
        s_St_1_BlackPIDFollower = Line_follower__St_1_Intersection;
      } else {
        r_St_1_BlackPIDFollower = v_123;
        s_St_1_BlackPIDFollower = v_122;
      };
      s = s_St_1_BlackPIDFollower;
      r = r_St_1_BlackPIDFollower;
      break;
    case Line_follower__St_1_OAS:
      v_115 = !(ir_front);
      if (v_115) {
        r_St_1_OAS = true;
        s_St_1_OAS = Line_follower__St_1_OASForward;
      } else {
        r_St_1_OAS = self->pnr;
        s_St_1_OAS = Line_follower__St_1_OAS;
      };
      s = s_St_1_OAS;
      r = r_St_1_OAS;
      break;
    case Line_follower__St_1_OASForward:
      v_111 = !(rc);
      v_109 = !(cc);
      v_108 = !(lc);
      v_110 = (v_108&&v_109);
      v_112 = (v_110&&v_111);
      if (v_112) {
        v_114 = true;
        v_113 = Line_follower__St_1_Intersection;
      } else {
        v_114 = self->pnr;
        v_113 = Line_follower__St_1_OASForward;
      };
      v_107 = !(ir_left);
      if (v_107) {
        r_St_1_OASForward = true;
        s_St_1_OASForward = Line_follower__St_1_OASLeft;
      } else {
        r_St_1_OASForward = v_114;
        s_St_1_OASForward = v_113;
      };
      s = s_St_1_OASForward;
      r = r_St_1_OASForward;
      break;
    case Line_follower__St_1_OASLeft:
      if (ir_left) {
        r_St_1_OASLeft = true;
        s_St_1_OASLeft = Line_follower__St_1_OASForward;
      } else {
        r_St_1_OASLeft = self->pnr;
        s_St_1_OASLeft = Line_follower__St_1_OASLeft;
      };
      s = s_St_1_OASLeft;
      r = r_St_1_OASLeft;
      break;
    case Line_follower__St_1_GoToParking:
      r_St_1_GoToParking = self->pnr;
      s_St_1_GoToParking = Line_follower__St_1_GoToParking;
      s = s_St_1_GoToParking;
      r = r_St_1_GoToParking;
      break;
    default:
      break;
  };
  ck_2 = s;
  switch (ck_2) {
    case Line_follower__St_1_Forward:
      counter_St_1_Forward = self->counter_1;
      v_r_St_1_Forward = 34;
      v_l_St_1_Forward = 34;
      dir_St_1_Forward = 1;
      nr_St_1_Forward = false;
      ns_St_1_Forward = Line_follower__St_1_Forward;
      counter = counter_St_1_Forward;
      _out->v_l = v_l_St_1_Forward;
      _out->v_r = v_r_St_1_Forward;
      _out->dir = dir_St_1_Forward;
      ns = ns_St_1_Forward;
      nr = nr_St_1_Forward;
      break;
    case Line_follower__St_1_PIDFollower:
      counter_St_1_PIDFollower = self->counter_1;
      if (self->v_343) {
        v_344 = true;
      } else {
        v_344 = r;
      };
      if (v_344) {
        v_346 = 0;
      } else {
        v_346 = self->v_345;
      };
      if (self->v_339) {
        v_340 = true;
      } else {
        v_340 = r;
      };
      error = (sen3-sen1);
      v_347 = (error/Line_follower__kp);
      error_derivative = (error-v_346);
      v_350 = (error_derivative/Line_follower__kd);
      v_342 = (self->v_341+error);
      if (v_340) {
        error_longegral = 0;
      } else {
        error_longegral = v_342;
      };
      v_348 = (error_longegral/Line_follower__ki);
      v_349 = (v_347+v_348);
      temp_value = (v_349+v_350);
      v_351 = (temp_value<0);
      if (v_351) {
        pid_value = -20;
      } else {
        pid_value = 20;
      };
      v_356 = (pid_value==0);
      v_355 = (30-pid_value);
      v_354 = (pid_value==0);
      if (v_354) {
        v_r_St_1_PIDFollower = 25;
      } else {
        v_r_St_1_PIDFollower = v_355;
      };
      v_353 = (30+pid_value);
      v_352 = (pid_value==0);
      if (v_352) {
        v_l_St_1_PIDFollower = 25;
      } else {
        v_l_St_1_PIDFollower = v_353;
      };
      nr_St_1_PIDFollower = false;
      ns_St_1_PIDFollower = Line_follower__St_1_PIDFollower;
      counter = counter_St_1_PIDFollower;
      _out->v_l = v_l_St_1_PIDFollower;
      _out->v_r = v_r_St_1_PIDFollower;
      v_357 = (_out->v_l<_out->v_r);
      if (v_357) {
        v_358 = 2;
      } else {
        v_358 = 3;
      };
      if (v_356) {
        dir_St_1_PIDFollower = 1;
      } else {
        dir_St_1_PIDFollower = v_358;
      };
      _out->dir = dir_St_1_PIDFollower;
      ns = ns_St_1_PIDFollower;
      nr = nr_St_1_PIDFollower;
      break;
    case Line_follower__St_1_Left:
      counter_St_1_Left = self->counter_1;
      v_r_St_1_Left = 90;
      v_l_St_1_Left = 90;
      dir_St_1_Left = 4;
      if (cc) {
        v_334 = true;
        v_333 = Line_follower__St_1_Forward;
      } else {
        v_334 = false;
        v_333 = Line_follower__St_1_Left;
      };
      v_330 = (rc||rr);
      v_331 = !(v_330);
      v_332 = (lc&&v_331);
      if (v_332) {
        v_336 = true;
        v_335 = Line_follower__St_1_PIDFollower;
      } else {
        v_336 = v_334;
        v_335 = v_333;
      };
      v_327 = (ll||lc);
      v_328 = !(v_327);
      v_329 = (rc&&v_328);
      if (v_329) {
        v_338 = true;
        v_337 = Line_follower__St_1_PIDFollower;
      } else {
        v_338 = v_336;
        v_337 = v_335;
      };
      v_325 = (cc&&rc);
      v_326 = (v_325&&rr);
      if (v_326) {
        nr_St_1_Left = true;
        ns_St_1_Left = Line_follower__St_1_Right;
      } else {
        nr_St_1_Left = v_338;
        ns_St_1_Left = v_337;
      };
      counter = counter_St_1_Left;
      _out->v_l = v_l_St_1_Left;
      _out->v_r = v_r_St_1_Left;
      _out->dir = dir_St_1_Left;
      ns = ns_St_1_Left;
      nr = nr_St_1_Left;
      break;
    case Line_follower__St_1_Right:
      counter_St_1_Right = self->counter_1;
      v_r_St_1_Right = 90;
      v_l_St_1_Right = 90;
      dir_St_1_Right = 5;
      nr_St_1_Right = false;
      ns_St_1_Right = Line_follower__St_1_Right;
      counter = counter_St_1_Right;
      _out->v_l = v_l_St_1_Right;
      _out->v_r = v_r_St_1_Right;
      _out->dir = dir_St_1_Right;
      ns = ns_St_1_Right;
      nr = nr_St_1_Right;
      break;
    case Line_follower__St_1_BlackForward:
      counter_St_1_BlackForward = self->counter_1;
      v_r_St_1_BlackForward = 35;
      v_l_St_1_BlackForward = 35;
      dir_St_1_BlackForward = 1;
      nr_St_1_BlackForward = false;
      ns_St_1_BlackForward = Line_follower__St_1_BlackForward;
      counter = counter_St_1_BlackForward;
      _out->v_l = v_l_St_1_BlackForward;
      _out->v_r = v_r_St_1_BlackForward;
      _out->dir = dir_St_1_BlackForward;
      ns = ns_St_1_BlackForward;
      nr = nr_St_1_BlackForward;
      break;
    case Line_follower__St_1_Intersection:
      counter_St_1_Intersection = (self->counter_1+1);
      dir_St_1_Intersection = 10;
      v_312 = !(cc);
      if (v_312) {
        v_314 = true;
        v_313 = Line_follower__St_1_BlackForward;
      } else {
        v_314 = false;
        v_313 = Line_follower__St_1_Intersection;
      };
      v_309 = !(rc);
      v_310 = (v_309&&ll);
      v_311 = (v_310&&lc);
      if (v_311) {
        v_316 = true;
        v_315 = Line_follower__St_1_BlackPIDFollower;
      } else {
        v_316 = v_314;
        v_315 = v_313;
      };
      v_306 = !(lc);
      v_307 = (v_306&&rc);
      v_308 = (v_307&&rr);
      if (v_308) {
        v_318 = true;
        v_317 = Line_follower__St_1_BlackPIDFollower;
      } else {
        v_318 = v_316;
        v_317 = v_315;
      };
      counter = counter_St_1_Intersection;
      timer = counter;
      v_323 = (counter<=5);
      v_322 = (counter<=3);
      v_324 = (v_322&&v_323);
      if (v_324) {
        v_r_St_1_Intersection = 0;
      } else {
        v_r_St_1_Intersection = 50;
      };
      v_320 = (counter>=6);
      v_319 = (counter<=3);
      v_321 = (v_319||v_320);
      if (v_321) {
        v_l_St_1_Intersection = 50;
      } else {
        v_l_St_1_Intersection = 0;
      };
      v_305 = (timer==6);
      if (v_305) {
        nr_St_1_Intersection = true;
        ns_St_1_Intersection = Line_follower__St_1_GoToParking;
      } else {
        nr_St_1_Intersection = v_318;
        ns_St_1_Intersection = v_317;
      };
      _out->v_l = v_l_St_1_Intersection;
      _out->v_r = v_r_St_1_Intersection;
      _out->dir = dir_St_1_Intersection;
      ns = ns_St_1_Intersection;
      nr = nr_St_1_Intersection;
      break;
    case Line_follower__St_1_BlackPIDFollower:
      counter_St_1_BlackPIDFollower = self->counter_1;
      if (self->v_289) {
        v_290 = true;
      } else {
        v_290 = r;
      };
      if (v_290) {
        v_292 = 0;
      } else {
        v_292 = self->v_291;
      };
      if (self->v_285) {
        v_286 = true;
      } else {
        v_286 = r;
      };
      error_2 = (sen3-sen1);
      v_293 = (error_2/Line_follower__kp);
      error_derivative_2 = (error_2-v_292);
      v_296 = (error_derivative_2/Line_follower__kd);
      v_288 = (self->v_287+error_2);
      if (v_286) {
        error_longegral_2 = 0;
      } else {
        error_longegral_2 = v_288;
      };
      v_294 = (error_longegral_2/Line_follower__ki);
      v_295 = (v_293+v_294);
      temp_value_2 = (v_295+v_296);
      v_297 = (temp_value_2<0);
      if (v_297) {
        pid_value_2 = -20;
      } else {
        pid_value_2 = 20;
      };
      v_302 = (pid_value_2==0);
      v_301 = (30+pid_value_2);
      v_300 = (pid_value_2==0);
      if (v_300) {
        v_r_St_1_BlackPIDFollower = 25;
      } else {
        v_r_St_1_BlackPIDFollower = v_301;
      };
      v_299 = (30-pid_value_2);
      v_298 = (pid_value_2==0);
      if (v_298) {
        v_l_St_1_BlackPIDFollower = 25;
      } else {
        v_l_St_1_BlackPIDFollower = v_299;
      };
      nr_St_1_BlackPIDFollower = false;
      ns_St_1_BlackPIDFollower = Line_follower__St_1_BlackPIDFollower;
      counter = counter_St_1_BlackPIDFollower;
      _out->v_l = v_l_St_1_BlackPIDFollower;
      _out->v_r = v_r_St_1_BlackPIDFollower;
      v_303 = (_out->v_l<_out->v_r);
      if (v_303) {
        v_304 = 2;
      } else {
        v_304 = 3;
      };
      if (v_302) {
        dir_St_1_BlackPIDFollower = 1;
      } else {
        dir_St_1_BlackPIDFollower = v_304;
      };
      _out->dir = dir_St_1_BlackPIDFollower;
      ns = ns_St_1_BlackPIDFollower;
      nr = nr_St_1_BlackPIDFollower;
      break;
    case Line_follower__St_1_OAS:
      counter_St_1_OAS = self->counter_1;
      v_r_St_1_OAS = 90;
      v_l_St_1_OAS = 90;
      dir_St_1_OAS = 5;
      nr_St_1_OAS = false;
      ns_St_1_OAS = Line_follower__St_1_OAS;
      counter = counter_St_1_OAS;
      _out->v_l = v_l_St_1_OAS;
      _out->v_r = v_r_St_1_OAS;
      _out->dir = dir_St_1_OAS;
      ns = ns_St_1_OAS;
      nr = nr_St_1_OAS;
      break;
    case Line_follower__St_1_OASForward:
      counter_St_1_OASForward = self->counter_1;
      v_r_St_1_OASForward = 35;
      v_l_St_1_OASForward = 35;
      dir_St_1_OASForward = 1;
      nr_St_1_OASForward = false;
      ns_St_1_OASForward = Line_follower__St_1_OASForward;
      counter = counter_St_1_OASForward;
      _out->v_l = v_l_St_1_OASForward;
      _out->v_r = v_r_St_1_OASForward;
      _out->dir = dir_St_1_OASForward;
      ns = ns_St_1_OASForward;
      nr = nr_St_1_OASForward;
      break;
    case Line_follower__St_1_OASLeft:
      counter_St_1_OASLeft = self->counter_1;
      v_r_St_1_OASLeft = 90;
      v_l_St_1_OASLeft = 90;
      dir_St_1_OASLeft = 4;
      nr_St_1_OASLeft = false;
      ns_St_1_OASLeft = Line_follower__St_1_OASLeft;
      counter = counter_St_1_OASLeft;
      _out->v_l = v_l_St_1_OASLeft;
      _out->v_r = v_r_St_1_OASLeft;
      _out->dir = dir_St_1_OASLeft;
      ns = ns_St_1_OASLeft;
      nr = nr_St_1_OASLeft;
      break;
    case Line_follower__St_1_GoToParking:
      counter_St_1_GoToParking = self->counter_1;
      r_1 = r;
      if (r_1) {
        Line_follower__parking_reset(&self->parking);
      };
      Line_follower__parking_step(sen1, sen3, ll, lc, cc, rc, rr, ir_left,
                                  ir_right, &Line_follower__parking_out_st,
                                  &self->parking);
      v_l_St_1_GoToParking = Line_follower__parking_out_st.v_l;
      v_r_St_1_GoToParking = Line_follower__parking_out_st.v_r;
      dir_St_1_GoToParking = Line_follower__parking_out_st.dir;
      counter = counter_St_1_GoToParking;
      _out->v_l = v_l_St_1_GoToParking;
      _out->v_r = v_r_St_1_GoToParking;
      _out->dir = dir_St_1_GoToParking;
      v_284 = (_out->dir==50);
      if (v_284) {
        nr_St_1_GoToParking = true;
        ns_St_1_GoToParking = Line_follower__St_1_BlackForward;
      } else {
        nr_St_1_GoToParking = false;
        ns_St_1_GoToParking = Line_follower__St_1_GoToParking;
      };
      ns = ns_St_1_GoToParking;
      nr = nr_St_1_GoToParking;
      break;
    default:
      break;
  };
  sen[0] = sen0;
  sen[1] = sen1;
  sen[2] = sen2;
  sen[3] = sen3;
  sen[4] = sen4;
  self->counter_1 = counter;
  self->pnr = nr;
  self->ck = ns;
  switch (ck_2) {
    case Line_follower__St_1_PIDFollower:
      self->v_345 = error;
      self->v_343 = false;
      self->v_341 = error_longegral;
      self->v_339 = false;
      break;
    case Line_follower__St_1_BlackPIDFollower:
      self->v_291 = error_2;
      self->v_289 = false;
      self->v_287 = error_longegral_2;
      self->v_285 = false;
      break;
    default:
      break;
  };;
}

